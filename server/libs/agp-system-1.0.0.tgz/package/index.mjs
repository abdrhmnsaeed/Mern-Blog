import createAGPGateway from './gateway/agp-bouncer.dist.mjs';

export const agpGateway = createAGPGateway;
